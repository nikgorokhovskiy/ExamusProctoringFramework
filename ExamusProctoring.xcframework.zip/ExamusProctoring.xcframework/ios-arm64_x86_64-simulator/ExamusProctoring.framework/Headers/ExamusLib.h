#import <Foundation/Foundation.h>

//! Project version number for ExamusLib.
FOUNDATION_EXPORT double ExamusVersionNumber;

//! Project version string for ExamusLib.
FOUNDATION_EXPORT const unsigned char ExamusVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ExamusLib/PublicHeader.h>


